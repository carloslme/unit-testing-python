import sys
sys.path.append('proyecto/app')
sys.path.append('../')

import pytest

import proyecto.app.funciones as tf

# Pruebas para el nombre
def obtener_datos_test_nombre():
        return [("carlos","Carlos"), ("MiGuel", "Miguel"), ("iVAN", "Ivan")]

@pytest.mark.parametrize('nombre, esperado', obtener_datos_test_nombre())
def test_nombre_parametrize(nombre, esperado):
        assert tf.procesar_nombre(nombre) == esperado

# Pruebas para el apellido paterno
def obtener_datos_test_ap():
        return [("LOPEZ","Lopez"), ("EspiNOZA", "Espinoza"), ("LEMINI", "Lemini")]

@pytest.mark.parametrize('ap, esperado', obtener_datos_test_ap())
def test_ap_parametrize(ap, esperado):
        assert tf.procesar_apellido_paterno(ap) == esperado

# Pruebas para el apellido materno
def obtener_datos_test_am():
        return [("ferrer","Ferrer"), ("SILVa", "Silva"), ("PalafoX", "Palafox")]

@pytest.mark.parametrize('am, esperado', obtener_datos_test_am())
def test_am_parametrize(am, esperado):
        assert tf.procesar_apellido_paterno(am) == esperado