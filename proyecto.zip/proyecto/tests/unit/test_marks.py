import sys
sys.path.append('proyecto/app')
sys.path.append('../')

import pytest

import proyecto.app.funciones as tf

@pytest.mark.skip(reason="No hay forma de probar esto ahora")
def test_calcular_curp():
    pass

#   xfail
@pytest.mark.xfail
def test_nombre_falla():
    assert tf.procesar_nombre(12) == "Doce"

#   Escribir una marca personal
@pytest.mark.mi_marca
def test_mi_marca():
    assert tf.procesar_nombre("jorgE") == "Jorge"