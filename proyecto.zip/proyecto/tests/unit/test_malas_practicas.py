import sys
sys.path.append('proyecto/app')
sys.path.append('../')

import proyecto.app.funciones as tf

# Pruebas para el nombre
def test_procesar_nombre():
  assert tf.procesar_nombre("carlos") == "Carlos"

def test_procesar_nombre_2():
  assert tf.procesar_nombre("MiGuel") == "Miguel"

def test_procesar_nombre_3():
  assert tf.procesar_nombre("iVAN") == "Ivan"